import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Fungsi untuk memuat dataset
@st.cache_data
def load_dataset(path):
    return pd.read_csv(path)

# Memuat dataset
data_customers_dataset = load_dataset('c:\\Users\\user\\Downloads\\Analisis data Dicoding\\data\\customers_dataset.csv')
data_order_items_dataset = load_dataset('c:\\Users\\user\\Downloads\\Analisis data Dicoding\\data\\order_items_dataset.csv')
data_order_reviews_dataset = load_dataset('c:\\Users\\user\\Downloads\\Analisis data Dicoding\\data\\order_reviews_dataset.csv')
data_orders_dataset = load_dataset('c:\\Users\\user\\Downloads\\Analisis data Dicoding\\data\\orders_dataset.csv')
data_products_dataset = load_dataset('c:\\Users\\user\\Downloads\\Analisis data Dicoding\\data\\products_dataset.csv')
data_sellers_dataset = load_dataset('c:\\Users\\user\\Downloads\\Analisis data Dicoding\\data\\sellers_dataset.csv')

# Judul aplikasi
st.title("E-Commerce Public Dataset")

# Menampilkan data mentah
st.subheader("Data Mentah")
if st.checkbox("Tampilkan data mentah order_items_dataset"):
    st.write(data_order_items_dataset)

if st.checkbox("Tampilkan data mentah order_reviews_dataset"):
    st.write(data_order_reviews_dataset)

if st.checkbox("Tampilkan data mentah orders_dataset"):
    st.write(data_orders_dataset)

if st.checkbox("Tampilkan data mentah products_dataset"):
    st.write(data_products_dataset)

if st.checkbox("Tampilkan data mentah sellers_dataset"):
    st.write(data_sellers_dataset)

# Bagian: Analisis Produk Penjualan Tertinggi
st.subheader("Produk Penjualan Tertinggi Berdasarkan City dan State dari Tren Bulan")

# Menggabungkan dataset yang relevan
@st.cache_data
def prepare_data():
    # Gabungkan dataset orders, order_items, products, sellers, dan customers
    combined_data = pd.merge(data_orders_dataset, data_order_items_dataset, on='order_id', how='inner')
    combined_data = pd.merge(combined_data, data_products_dataset, on='product_id', how='inner')
    combined_data = pd.merge(combined_data, data_sellers_dataset, on='seller_id', how='inner')
    combined_data = pd.merge(combined_data, data_customers_dataset, on='customer_id', how='inner')
    
    # Tambahkan kolom bulan dari order_purchase_timestamp
    combined_data['order_purchase_timestamp'] = pd.to_datetime(combined_data['order_purchase_timestamp'])
    combined_data['month'] = combined_data['order_purchase_timestamp'].dt.to_period('M')
    
    return combined_data

# Siapkan data
combined_data = prepare_data()

# Pilihan interaktif untuk state dan bulan
selected_seller_state = st.selectbox(
    "Pilih State Penjual",
    combined_data['seller_state'].unique(),
    key="seller_state"
)
selected_month = st.selectbox(
    "Pilih Bulan",
    combined_data['month'].astype(str).unique(),
    key="month"
)

# Filter data
filtered_data = combined_data[
    (combined_data['seller_state'] == selected_seller_state) & 
    (combined_data['month'].astype(str) == selected_month)
]

# Hitung produk dengan penjualan tertinggi
if not filtered_data.empty:
    top_products = (
        filtered_data.groupby(['seller_city', 'product_category_name'])['price']
        .sum()
        .reset_index()
        .sort_values(by='price', ascending=False)
    )

    # Visualisasi data
    st.subheader(f"Produk Penjualan Tertinggi di {selected_seller_state} untuk Bulan {selected_month}")
    fig, ax = plt.subplots(figsize=(12, 6))
    sns.barplot(
        data=top_products,
        x='seller_city',
        y='price',
        hue='product_category_name',
        ax=ax
    )
    ax.set_title(f"Produk Penjualan Tertinggi Berdasarkan City ({selected_month})")
    ax.set_ylabel("Total Penjualan (Rupiah)")
    ax.set_xlabel("Kota Penjual")
    ax.tick_params(axis='x', rotation=45)
    st.pyplot(fig)
else:
    st.warning("Tidak ada data untuk kombinasi State dan Bulan yang dipilih.")


# Bagian: Profil demografis pelanggan
st.subheader("Profil Demografis Pelanggan Berdasarkan State dan Product Category")

# Menggabungkan dataset yang relevan
@st.cache_data
def prepare_demographics_data():
    # Gabungkan dataset orders, order_items, dan products
    combined_data = pd.merge(data_orders_dataset, data_order_items_dataset, on='order_id', how='inner')
    combined_data = pd.merge(combined_data, data_products_dataset, on='product_id', how='inner')
    combined_data = pd.merge(combined_data, data_sellers_dataset, on='seller_id', how='inner')
    
    # Tambahkan data state pelanggan dari customers_dataset
    combined_data = pd.merge(combined_data, data_customers_dataset, on='customer_id', how='inner')
    
    # Tambahkan kolom bulan dari order_purchase_timestamp
    combined_data['order_purchase_timestamp'] = pd.to_datetime(combined_data['order_purchase_timestamp'])
    combined_data['month'] = combined_data['order_purchase_timestamp'].dt.to_period('M').astype(str)
    
    return combined_data

# Siapkan data untuk analisis
demographics_data = prepare_demographics_data()

# Pilihan interaktif untuk State dan bulan
selected_state = st.selectbox("Pilih State", demographics_data['customer_state'].unique(), key="customer_state")
selected_month = st.selectbox("Pilih Bulan", demographics_data['month'].unique(), key="demographics_month")

# Filter data berdasarkan pilihan
filtered_data = demographics_data[
    (demographics_data['customer_state'] == selected_state) & 
    (demographics_data['month'] == selected_month)
]

# Cek jika data kosong
if not filtered_data.empty:
    # Hitung produk dengan penjualan tertinggi berdasarkan city
    top_products = (
        filtered_data.groupby(['seller_city', 'product_category_name'])['price']
        .sum()
        .reset_index()
        .sort_values(by='price', ascending=False)
    )

    # Visualisasi data
    st.subheader(f"Produk Penjualan Tertinggi di {selected_state} untuk Bulan {selected_month}")
    fig, ax = plt.subplots(figsize=(12, 6))
    sns.barplot(
        data=top_products,
        x='seller_city',
        y='price',
        hue='product_category_name',
        ax=ax
    )
    ax.set_title(f"Produk Penjualan Tertinggi Berdasarkan City ({selected_month})")
    ax.set_ylabel("Total Penjualan (Rupiah)")
    ax.set_xlabel("Kota Penjual")
    ax.tick_params(axis='x', rotation=45)
    st.pyplot(fig)
else:
    st.warning("Tidak ada data untuk kombinasi State dan Bulan yang dipilih.")
